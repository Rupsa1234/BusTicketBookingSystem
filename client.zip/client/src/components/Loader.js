import React from "react";

function Loader() {
  return (
    <div className="spinner-parent">
      <div class="spinner-border" role="status">
     
      </div>
    </div>
  );
}

export default Loader;
